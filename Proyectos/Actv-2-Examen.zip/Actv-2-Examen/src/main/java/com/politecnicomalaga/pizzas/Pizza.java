package com.politecnicomalaga.pizzas;

public class Pizza {

    //public abstract String preparar();
    public String hornear(){
        return "  Introducir en el horno durante 20 minutos";
    }

    public String cortar(){
        return "  Cortar en 8 trozos iguales";
    }

    public String empaquetar(){
        return "  Introducir en una caja";
    }
}
