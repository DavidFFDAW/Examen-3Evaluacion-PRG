package com.politecnicomalaga.factory;

public interface HacerPizza {
    public String preparar();
}
